DESC country 


DESC country  Name


DESC country 'GNP%'
