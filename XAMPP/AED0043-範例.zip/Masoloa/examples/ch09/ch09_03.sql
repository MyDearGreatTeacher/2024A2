ALTER TABLE addressbook
DROP PRIMARY KEY,
DROP INDEX email,
DROP INDEX name,
DROP INDEX address


DROP INDEX 'PRIMARY' ON addressbook


DROP INDEX email ON addressbook


DROP INDEX name ON addressbook


DROP INDEX address ON addressbook
