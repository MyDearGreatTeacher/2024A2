SHOW INDEX FROM addressbook
