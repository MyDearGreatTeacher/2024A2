import mysql.connector

connection = None

try:
    connection = mysql.connector.connect(host="localhost",
                                         port="3306",        
                                         user="root",
                                         password="password",
                                         database="cmdev")
    cursor = connection.cursor()

    sql = "DELETE FROM cmdev.dept WHERE deptno=96"
    
    cursor.execute(sql)
    
    connection.commit()
    
    if cursor.rowcount > 0:
        print("Delete sucessful!")
except mysql.connector.Error as error:
    print(error)
finally:
    if connection is not None and connection.is_connected():
        connection.close()