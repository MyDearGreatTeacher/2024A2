import mysql.connector

connection = None

try:
    connection = mysql.connector.connect(host="localhost",
                                         port="3306",
                                         user="root",
                                         password="password",
                                         database="cmdev")
    print("Connection successed!")
except mysql.connector.Error as error:
    print("Error code:{}".format(error.errno))
    print("SQL state:{}".format(error.sqlstate))
    print("Message:{}".format(error.msg))
    print("Error:{}".format(error))    
finally:
    if connection is not None and connection.is_connected():
        connection.close()
