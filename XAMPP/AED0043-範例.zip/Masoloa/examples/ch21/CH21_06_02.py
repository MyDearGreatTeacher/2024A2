import mysql.connector

connection = None

try:
    connection = mysql.connector.connect(host="localhost",
                                         port="3306",        
                                         user="root",
                                         password="password",
                                         database="cmdev")
    cursor = connection.cursor()

    sql = "SELECT * FROM dept"
    
    cursor.execute(sql)

    rows = cursor.fetchmany(size = 2)

    for (deptno, dname, location) in rows:
        print("No:{}, Name:{}, Location:{}".format(deptno, dname, location))

    rows = cursor.fetchall()    

    for (deptno, dname, location) in rows:
        print("No:{}, Name:{}, Location:{}".format(deptno, dname, location))
except mysql.connector.Error as error:
    print(error)

finally:
    if connection is not None and connection.is_connected():
        connection.close()