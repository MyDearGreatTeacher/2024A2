import mysql.connector

connection = None

try:
    connection = mysql.connector.connect(host="localhost",
                                         port="3306",        
                                         user="root",
                                         password="password",
                                         database="cmdev")
    
    cursor = connection.cursor(prepared=True)

    sql = "SELECT * FROM cmdev.dept WHERE deptno=?"

    deptno = (20,)

    cursor.execute(sql, deptno)

    row = cursor.fetchone()

    if row is not None:
        print("No:{}, Name:{}, Location:{}".format(row[0], row[1], row[2]))
    else:
        print("Record not found: deptno {}".format(deptno))

    cursor.execute(sql, (999,))
    
    row = cursor.fetchone()

    if row is not None:
        print("No:{}, Name:{}, Location:{}".format(row[0], row[1], row[2]))
    else:
        print("Record not found: deptno 999")        

except mysql.connector.Error as error:
    print(error)
finally:
    if connection is not None and connection.is_connected():
        connection.close()