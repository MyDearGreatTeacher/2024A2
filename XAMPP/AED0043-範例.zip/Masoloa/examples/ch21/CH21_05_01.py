import mysql.connector
from mysql.connector import errorcode

connection = None

try:
    connection = mysql.connector.connect(host="localhost",
                                         port="3306",
                                         user="root",
                                         password="password",
                                         database="notexist")
    print("Connection successed!")
except mysql.connector.Error as error:
    if error.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("Something is wrong with user name or password")
    elif error.errno == errorcode.ER_BAD_DB_ERROR:
        print("Database does not exist")        
    else: 
        print("Error code:{}".format(error.errno))
        print("SQL state:{}".format(error.sqlstate))
        print("Message:{}".format(error.msg))
        print("Error:{}".format(error))    
finally:
    if connection is not None and connection.is_connected():
        connection.close()
