import mysql.connector

connection = None

try:
    connection = mysql.connector.connect(host="localhost",
                                         port="3306",        
                                         user="root",
                                         password="password",
                                         database="cmdev")

    cursor = connection.cursor(prepared=True)

    sql = "INSERT INTO cmdev.dept (deptno, dname, location) VALUES (?, ?, ?)"

    data = (97, "MARKETING", "BOSTON")

    cursor.execute(sql, data)

    connection.commit()
except mysql.connector.Error as error:
    print(error)
finally:
    if connection is not None and connection.is_connected():
        connection.close()