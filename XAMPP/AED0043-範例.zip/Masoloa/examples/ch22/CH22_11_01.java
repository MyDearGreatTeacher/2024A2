import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CH22_11_01 {

	public static void main(String[] args) {
		final String URL = "jdbc:mysql://localhost:3306/cmdev";
		final String USER_NAME = "root";
		final String PASSWORD = "password";
		
		final String SQL = "INSERT INTO cmdev.dept (deptno, dname, location) " +
					"VALUES (90, 'MARKETING', 'BOSTON')";
		
		try (Connection conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
				Statement stmt = conn.createStatement()) {
			int result = stmt.executeUpdate(SQL);
			
			if (result > 0) {
				System.out.println("Insert sucessful!");
			}
		}
		catch (SQLException e) {
			System.out.println("SQLException: " + e);
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("ErrorCode: " + e.getErrorCode());
		}
	}

}
