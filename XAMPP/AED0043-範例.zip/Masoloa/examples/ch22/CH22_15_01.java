import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

public class CH22_15_01 {

	public static void main(String[] args) {
		final String URL = "jdbc:mysql://localhost:3306/cmdev";
		final String USER_NAME = "root";
		final String PASSWORD = "password";
		
		final String SQL = "call cmdev.empsalaryinfo(?, ?, ?)";
		final int deptno = 20;
		
		try (Connection conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
				CallableStatement cstmt = conn.prepareCall(SQL)) {
			cstmt.setInt(1, deptno);
			
			cstmt.registerOutParameter(2, Types.DECIMAL);
			cstmt.registerOutParameter(3, Types.DECIMAL);
			
			cstmt.execute();
			
			double max = cstmt.getDouble(2);
			double min = cstmt.getDouble(3);
			
			System.out.printf("DeptNo: %d, Max: %.0f, Min: %.0f%n", deptno, max, min);
		}
		catch (SQLException e) {
			System.out.println("SQLException: " + e);
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("ErrorCode: " + e.getErrorCode());
		}
	}

}

//CREATE PROCEDURE empsalaryinfo(IN dno INT, OUT max DECIMAL, OUT min DECIMAL)
//BEGIN
//    SELECT MAX(salary) max, MIN(salary) min INTO max, min
//    FROM   emp 
//    WHERE  deptno=dno;
//END
