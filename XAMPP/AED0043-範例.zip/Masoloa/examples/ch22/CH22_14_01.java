import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CH22_14_01 {

	public static void main(String[] args) {
		final String URL = "jdbc:mysql://localhost:3306/cmdev";
		final String USER_NAME = "root";
		final String PASSWORD = "password";
		
		final String SQL = "INSERT INTO cmdev.dept (deptno, dname, location) " + 
					"VALUES (?, ?, ?)";
		
		try (Connection conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(SQL)) {
			pstmt.setInt(1, 92);
			pstmt.setString(2, "SERVICE");
			pstmt.setString(3, "DALLAS");
			
			int result = pstmt.executeUpdate();
			
			if (result > 0) {
				System.out.println("Insert sucessful!");
			}
		}
		catch (SQLException e) {
			System.out.println("SQLException: " + e);
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("ErrorCode: " + e.getErrorCode());
		}
	}

}
