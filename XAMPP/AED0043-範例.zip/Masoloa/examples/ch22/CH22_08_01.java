import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CH22_08_01 {

	public static void main(String[] args) {
		final String URL = "jdbc:mysql://localhost:3306/cmdev";
		final String USER_NAME = "root";
		final String PASSWORD = "password";
		
		final String SQL = "SELECT * FROM cmdev.dept";
		
		try (Connection conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
				Statement stmt = conn.createStatement();
				ResultSet result = stmt.executeQuery(SQL)) {
			while (result.next()) {
				int deptno = result.getInt(1);
				String dname = result.getString(2);
				String location = result.getString(3);
				
				System.out.printf("%d, %s, %s%n", deptno, dname, location);
			}
		}
		catch (SQLException e) {
			System.out.println("SQLException: " + e);
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("ErrorCode: " + e.getErrorCode());
		}
	}

}
