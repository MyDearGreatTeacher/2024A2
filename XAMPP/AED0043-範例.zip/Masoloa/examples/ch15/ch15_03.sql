CREATE PROCEDURE cmdev.test_handler5( p_deptno INT,
                                      p_dname VARCHAR(16),
                                      p_location VARCHAR(16) )
BEGIN
    DECLARE v_messgae VARCHAR(64) DEFAULT 'Success!';

    DECLARE c_null CONDITION FOR 1048;
    DECLARE c_dupkey CONDITION FOR 1062;

    DECLARE CONTINUE HANDLER FOR c_null
    BEGIN
        SET v_messgae = 'Cannot be null!';
    END;
    DECLARE CONTINUE HANDLER FOR c_dupkey
    BEGIN
        SET v_messgae = 'Duplicate key!';
    END;
    INSERT INTO cmdev.dept
    VALUES (p_deptno, p_dname, p_location);
    INSERT INTO deptlog (message) VALUES (v_messgae);
END

