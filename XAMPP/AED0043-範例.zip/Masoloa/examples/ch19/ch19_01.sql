SELECT * INTO OUTFILE 'C:/Masoloa/data/out/dept.txt'
FROM   cmdev.dept


SELECT * INTO OUTFILE 'C:/Masoloa/data/out/dept2.txt'
FIELDS TERMINATED BY '|'
FROM   cmdev.dept


SELECT * INTO OUTFILE 'C:/Masoloa/data/out/dept3.txt'
FIELDS ENCLOSED BY '*'
FROM   cmdev.dept


SELECT empno, ename, salary, deptno
INTO OUTFILE 'C:/Masoloa/data/out/emp.txt'
FROM   cmdev.emp
WHERE  salary < 1500


SELECT empno, ename, salary, deptno
INTO OUTFILE 'C:/Masoloa/data/out/emp2.txt'
FIELDS ESCAPED BY '$'
FROM   cmdev.emp
WHERE  salary < 1500


SELECT empno, ename, salary, deptno
INTO OUTFILE 'C:/Masoloa/data/out/emp3.txt'
LINES STARTING BY '>>>' TERMINATED BY '\n'
FROM   cmdev.emp
WHERE  salary < 1500


SELECT * INTO OUTFILE 'C:/Masoloa/data/out/deptcsv.txt'
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r'
FROM   cmdev.dept
